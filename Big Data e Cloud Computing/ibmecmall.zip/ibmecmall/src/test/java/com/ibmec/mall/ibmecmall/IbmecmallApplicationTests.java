package com.ibmec.mall.ibmecmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbmecmallApplicationTests {

	@Test
	void contextLoads() {
	}

}
